#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
chmod +x "$DIR/loadforge"
"$DIR/loadforge" -port 8080 -browser
