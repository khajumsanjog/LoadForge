#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
xattr -d com.apple.quarantine "$DIR/loadforge" 2>/dev/null || true
xattr -cr "$DIR" 2>/dev/null || true
chmod +x "$DIR/loadforge"
"$DIR/loadforge" -port 8080 -browser
